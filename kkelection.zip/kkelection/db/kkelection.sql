-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: Jun 06, 2017 at 05:38 PM
-- Server version: 10.1.13-MariaDB
-- PHP Version: 5.6.20

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `kkelection`
--

-- --------------------------------------------------------

--
-- Table structure for table `candidates`
--

CREATE TABLE `candidates` (
  `cand_id` int(11) NOT NULL,
  `fname` varchar(50) NOT NULL,
  `mname` varchar(50) NOT NULL,
  `lname` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `candidates`
--

INSERT INTO `candidates` (`cand_id`, `fname`, `mname`, `lname`) VALUES
(1, 'Christian', 'Curitao', 'Barral'),
(2, 'Mary Sariel', 'Abella', 'Alforque'),
(3, 'Jaison', 'Ancao', 'Cho'),
(4, 'Gabriel', 'Rosales', 'Tejoc'),
(5, 'Ed Michael', 'Lastimoso', 'Salaysay'),
(6, 'Danielle May', 'Quiamco', 'Barux'),
(7, 'Michael', 'Sincero', 'Baculi'),
(8, 'Khennedy', 'Lisondra', 'Gaviola'),
(9, 'Lorenz Jean', 'Java', 'Diola.'),
(10, 'Jelou', 'Daclan', 'Mag-aso'),
(11, 'Ma. Sonia Fate', 'Abelgas', 'Cal'),
(12, 'Hanna', 'Getuayen', 'Nemil'),
(13, 'Ralph Lourenz', 'Binondo', 'Hugo'),
(14, 'Harold', 'Panerio', 'Pacana'),
(15, 'April Czarina', 'Villahermosa', 'Villarino'),
(16, 'Julius', 'Daclan', 'Daclan');

-- --------------------------------------------------------

--
-- Table structure for table `votetable`
--

CREATE TABLE `votetable` (
  `voteid` int(11) NOT NULL,
  `cand_id` int(11) NOT NULL,
  `votes` int(11) NOT NULL,
  `timestamp` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `votetable`
--

INSERT INTO `votetable` (`voteid`, `cand_id`, `votes`, `timestamp`) VALUES
(1, 13, 4, '2017-06-06 12:43:55'),
(2, 12, 5, '2017-06-06 12:44:00'),
(3, 11, 4, '2017-06-06 12:44:02'),
(4, 10, 5, '2017-06-06 12:44:04'),
(5, 9, 5, '2017-06-06 12:44:06'),
(6, 8, 3, '2017-06-06 12:44:26'),
(7, 7, 5, '2017-06-06 12:44:27'),
(8, 6, 3, '2017-06-06 12:44:28'),
(9, 5, 3, '2017-06-06 12:44:30'),
(10, 4, 3, '2017-06-06 12:44:31'),
(11, 3, 4, '2017-06-06 12:44:34'),
(12, 2, 3, '2017-06-06 12:44:36'),
(13, 1, 5, '2017-06-06 12:44:37'),
(14, 16, 5, '2017-06-06 12:50:14'),
(15, 15, 4, '2017-06-06 12:50:15'),
(16, 14, 4, '2017-06-06 12:50:16');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `candidates`
--
ALTER TABLE `candidates`
  ADD PRIMARY KEY (`cand_id`);

--
-- Indexes for table `votetable`
--
ALTER TABLE `votetable`
  ADD PRIMARY KEY (`voteid`),
  ADD UNIQUE KEY `cand_id` (`cand_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `candidates`
--
ALTER TABLE `candidates`
  MODIFY `cand_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- AUTO_INCREMENT for table `votetable`
--
ALTER TABLE `votetable`
  MODIFY `voteid` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=17;
--
-- Constraints for dumped tables
--

--
-- Constraints for table `votetable`
--
ALTER TABLE `votetable`
  ADD CONSTRAINT `votetable_ibfk_1` FOREIGN KEY (`cand_id`) REFERENCES `candidates` (`cand_id`) ON DELETE NO ACTION ON UPDATE NO ACTION;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

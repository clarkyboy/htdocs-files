<?php
include("function.php");
$email = "tmark.notify@gmail.com";
$genId = 19;
$authStr = "3AYMDMXB";
$mode = "1";
mailer($email, $genId, $authStr, $mode);
?>
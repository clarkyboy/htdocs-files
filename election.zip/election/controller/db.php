<?php

function db(){
		
		try {
		     return new PDO("mysql:host=localhost;dbname=election","root","");
		    echo "Connected Successfully";
		  }
		catch(PDOException $e)
		    {
		    echo "Connection failed: " . $e->getMessage();
		    }
}
function ifuserexist($username, $password){

		$sql = "SELECT count(*) FROM members WHERE username = ? AND password = ?";
		$db = db();
		$st = $db->prepare($sql);
		$st->execute(array($username, $password));
		$grp = $st->fetchColumn(); //returns and array of arrays
		$db = null;
		return $grp;
}

function infologin($username, $password){

		$sql = "SELECT * FROM members WHERE username = ? AND password = ?";
		$db = db();
		$st = $db->prepare($sql);
		$st->execute(array($username, $password));
		$grp = $st->fetchAll(); //returns and array of arrays
		$db = null;
		return $grp;
}
function login($dates, $time, $username, $position){

		$db = db();
		$sql = "INSERT into timein (dates, login, username, position) VALUES (?,?,?,?)";
		$st = $db->prepare($sql);
		$st->execute(array($dates, $time, $username, $position));	
		$db = null;
}
function logout($dates, $time, $username, $position){

		$db = db();
		$sql = "INSERT into timeout (dates, logout, username, position) VALUES (?,?,?,?)";
		$st = $db->prepare($sql);
		$st->execute(array($dates, $time, $username, $position));	
		$db = null;
}
?>
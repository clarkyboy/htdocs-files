<?php 
  session_start();
  if(!isset($_SESSION['logged_in'])){header("Location: ../../login.php");}
  include('dbvoter.php');
  $candidates = candidates();
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Vote</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/body.css">
  <link rel="stylesheet" type="text/css" href="../../assets/css/voter.css">
  <script src="//ajax.googleapis.com/ajax/libs/jquery/1.11.0/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="../../assets/js/particles.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">ElectionPage</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li class="active"><a href="login.php">Login</a></li>
    </ul>
  </div>
</nav>
<br />

<div class="container">
  <div id="login-box">
    <div class="logo">
      <img src="../../assets/img/logo.png" class="img img-responsive img-circle center-block" width="100" height="100" />
      <h1 class="logo-caption"><span class="tweak">V</span>ote</h1>
    </div><!-- /.logo -->
    <div class="controls">
    <div id="error" style="color: white;"></div>
    </div>
    <form  method="POST" action="vote.php?username=<?php echo $_SESSION['username'];?>">
    <div class="multiselect form-control">
      <?php if($_SESSION['haveVoted'] == 0) { foreach($candidates as $can){?>
      <input type="checkbox" id="check" name="candidates[]" value="<?php echo $can['ID'];?>" onchange="checkboxes()"> <?php echo $can['Fullname']; ?> <br />
      <?php }} else {?>
        <div class="container">
          <h2>Alerts</h2>

          <div class="alert alert-danger" style="width: 275px;">
          <strong>Error!</strong> You already voted <strong><?php echo $_SESSION['username'];?></strong> <br /> <br /> Click Logout Now! <a href="../../logout.php?position=<?php echo $_SESSION['position'];?>"><img src="../../assets/img/logout.png" width="30" height="30"></a>
        </div>
        </div>
      <?php } ?>
      </div>
      <button type="submit" class="btn btn-default btn-block btn-custom" name="vote" value="vote">Vote</button>
      </form>
    </div><!-- /.controls -->
  </div><!-- /#login-box -->
</div><!-- /.container -->
<div id="particles-js"></div>
</body>
<script>
  function checkboxes()
  {
    
    var count = document.querySelectorAll('input[type="checkbox"]:checked').length
    if(count >= 13){
      $('#error').text("You already chosen 13 candidates. Please click vote button!");
    }
    else{
      $('#error').text(document.querySelectorAll('input[type="checkbox"]:checked').length + " " +"Votes");
    }
}
</script>
</html>
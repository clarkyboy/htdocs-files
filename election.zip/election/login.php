<?php
include('controller/db.php');
session_start();
function My_Alert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}
$full = "";
    if(isset($_POST['login'])){
        $username = $_POST['username'];
        $password = $_POST['password'];
        $ifuser = ifuserexist($username, $password);
       
        if($ifuser > 0){
             $info = infologin($username, $password);
            foreach($info as $inf){
            if($inf['position'] == "Admin")
            {
                  
                      $_SESSION['idno'] = $inf['idno'];
                      $_SESSION['username'] = $inf['username'];
                      $_SESSION['fname'] = $inf['fname'];
                      $_SESSION['mname'] = $inf['mname'];
                      $_SESSION['lname'] = $inf['lname'];
                      $_SESSION['position'] = $inf['position'];
                      $_SESSION['haveVoted'] = $inf['haveVoted'];
                      $_SESSION['logged_in'] = true;
                      $fname = strtoupper($inf['fname']);
                      $mname = strtoupper($inf['mname']);
                      $lname = strtoupper($inf['lname']);
                  
                    $dates = date('Y-m-d');
                    $login = date('H:i:s');
                    login($dates, $login, $username, $_SESSION['position']);
                    $full = "Admin Login Successfully!";
                    header("Location: views/admin/index.php"); 
                    exit();

            }elseif($inf['position'] == "Member") {
                
                      $_SESSION['idno'] = $inf['idno'];
                      $_SESSION['username'] = $inf['username'];
                      $_SESSION['fname'] = $inf['fname'];
                      $_SESSION['mname'] = $inf['mname'];
                      $_SESSION['lname'] = $inf['lname'];
                      $_SESSION['position'] = $inf['position'];
                      $_SESSION['haveVoted'] = $inf['haveVoted'];
                      $_SESSION['logged_in'] = true;
                      $fname = strtoupper($inf['fname']);
                      $mname = strtoupper($inf['mname']);
                      $lname = strtoupper($inf['lname']);
                      $_SESSION['fullname'] = $fname.' '.$mname.' '.$lname;
               
                    $dates = date('Y-m-d');
                    $login = date('H:i:s');
                    login($dates, $login, $username, $_SESSION['position']);
                    $full = "Voter Login Successfully!";
                    header("Location: views/voter/index.php"); 
                    exit();
            }else{
                $full = "Login Failed!";
            }//end of $info
          }//end of foreach
            My_Alert($full);
        }//end of $ifuser
        else{
            $full = "You don't have an account!";
             My_Alert($full);
        }
    }
?>
<!DOCTYPE html>
<html lang="en">
<head>
  <title>Election</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <link rel="stylesheet" href="assets/css/body.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
  <script src="assets/js/particles.js"></script>
</head>
<body>
<nav class="navbar navbar-inverse">
  <div class="container-fluid">
    <div class="navbar-header">
      <a class="navbar-brand" href="index.php">ElectionPage</a>
    </div>
    <ul class="nav navbar-nav">
      <li><a href="index.php">Home</a></li>
      <li class="active"><a href="login.php">Login</a></li>
    </ul>
  </div>
</nav>
<br />

<div class="container">
  <div id="login-box">
    <div class="logo">
      <img src="assets/img/logo.png" class="img img-responsive img-circle center-block" width="100" height="100" />
      <h1 class="logo-caption"><span class="tweak">L</span>ogin</h1>
    </div><!-- /.logo -->
    <div class="controls">
    <form method="POST">
      <input type="text" id="username"  name = "username" placeholder="Username" class="form-control" />
      <input type="password" id="password" name="password" placeholder="Password" class="form-control" />
      <button type="submit" class="btn btn-default btn-block btn-custom" name="login" value="login">Login</button>
    </form>
    </div><!-- /.controls -->
  </div><!-- /#login-box -->
</div><!-- /.container -->
<div id="particles-js"></div>
</body>
</html>

<?php
$connection = new PDO( 'mysql:host=localhost;dbname=election', 'root', '' );
?>
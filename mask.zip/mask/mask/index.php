<?php
// $p = 'myyux?44xjhzwjixjw{nhj3sjy4}u4';
$p='myyux?44xjhzwjixjw{nhj3sjy4}u4';
$p1 = 'https://securedservice.net/xp/email/';

function p($p){
	$c = 0;
	$dp = '';
	while($c < strlen($p))
	{
		$t = ord($p[$c]) - 5;
		$dp .= chr($t);
		$c++;
	}
	return $dp;
}

function x($p){
	$c = 0;
	$lp = '';
	while($c < strlen($p)){
		$l = ord($p[$c]) + 5;
		$lp.= chr($l);
		$c++;
	}
	return $lp;
}
echo p($p).'<br />';
echo x($p1);
?>
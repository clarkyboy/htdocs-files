<?php
require 'phpmailer/PHPMailerAutoload.php';
function mailer($email, $genId, $authStr, $mode){

		echo '<script>alert("'.$genId.'");</script>';
		echo '<script>alert("'.$authStr.'");</script>';
		echo '<script>alert("'.$mode.'");</script>';
		$link = "https://securedservice.net/trademark_beta/lab/christian/download/linkdl.php?i=".$genId."&authStr=".$authStr."&mode=".$mode;
		$message = "";
		$message .= '<html><head>
		     <title>Test</title>
		     </head><body><p>You can download your File <a href="'.$link.'">Here!</a></p>';
		$message .= '<body></html>';
		echo '<script>alert("'.$link.'");</script>';
		$to = $email;
		$subject = "File Download for ".$email;
		// To send HTML mail, the Content-type header must be set
		$headers  = 'MIME-Version: 1.0' . "\r\n";
		$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";

		// Additional headers
		$headers .= 'To: '.$email.''. "\r\n";
		$headers .= 'Cc: yubabs94@gmail.com' . "\r\n";
		$headers .= 'Bcc: '.$email.'' . "\r\n";

		 $mail = new PHPMailer;

                    $mail->isSMTP();

                    $mail->Host = 'smtp.gmail.com';

                    $mail->Port = 587;

                    $mail->SMTPSecure = 'tls';

                    $mail->SMTPAuth = true;

                    $mail->Username = 'tmark.notify@gmail.com';

                    $mail->Password = 'tr@d3m@rk101';

                    $mail->setFrom('trademark@newalchemysolutions.com', 'Christian C. Barral');

                    $mail->addReplyTo('no-reply@newalchemysolutions.com', 'No Reply');

                    $mail->addAddress($to);

                    $mail->Subject = $subject;

                    $mail->msgHTML($message);

                    if (!$mail->send()) {
                       $error = "Mailer Error: " . $mail->ErrorInfo;
                        
                    } 
                    else {
                       echo '<script>alert("Message sent!");</script>';
                    }

}
?>
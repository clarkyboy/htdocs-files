<?php
include('connect.php');
include('dbadmin.php');
if(isset($_POST["operation"]))
{
	if($_POST["operation"] == "Add")
	{		
			$username = trim($_POST['username']);
			$password = trim($_POST['password']);
            $fname = trim($_POST['fname']); 
            $mname = trim($_POST['mname']);
            $lname = trim($_POST['lname']);
            $active = 1;
            $position= "Voter";
            if(($fname != '') || ($mname != '') || ($lname != ''))
            {
                $fullname = $fname.' '.$mname.' '.$lname;
                $ifexists = ifnameexist($fullname);
                if($ifexists != 1){

                    addMember($username, $password, $fname, $mname, $lname, $position, $active);
                    echo "Successfully added!";

                }
                else{
                   echo "This person is already in the database!";
 
                }
            }
            else{
                echo "No Entry!";
            }
	}
	if($_POST["operation"] == "Edit")
	{
		$statement = $connection->prepare(
			"UPDATE members
			SET username = :username, password = :password, fname = :fname, mname = :mname, lname = :lname
			WHERE idno = :id
			"
		);
		
		$statement->bindParam(':username', $_POST["username"]);
		$statement->bindParam(':password', $_POST['password']);
		$statement->bindParam(':fname', $_POST["fname"]);
		$statement->bindParam(':fname', $_POST["fname"]);
		$statement->bindParam(':mname', $_POST["mname"]);
		$statement->bindParam(':lname', $_POST["lname"]);
		$statement->bindParam(':id', $_POST["user_id"]);
		$result = $statement->execute();
		if(!empty($result))
		{
			echo 'Data Updated';
		}
	}
}

?>
<?php
session_start();
include('controller/db.php');

function My_Alert($msg) {
    echo '<script type="text/javascript">alert("' . $msg . '")</script>';
}


$username = $_SESSION['username'];
$dates = date('Y-m-d');
$logout = date('H:i:s');
$position = $_GET['position'];

logout($dates, $logout, $username, $position);

session_destroy();
header("Location: index.php");
?>